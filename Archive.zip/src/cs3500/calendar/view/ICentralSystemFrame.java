package cs3500.calendar.view;

/**
 * To describe what the main system’s frame (and therefore the whole view) is capable of.
 */
public interface ICentralSystemFrame {

  //access an event frame when specific event is clicked on

  //load an xml file

  //select schedule to view

  //update all frames and panels

  //save current schedule to xml file

  //click a button to add an event

  //click button to schedule an event

  //close out window without quitting code


}
