package cs3500.calendar.view;

/**
 * To represent the event panel's capabilities. 
 */
public interface IEventPanel {
}
